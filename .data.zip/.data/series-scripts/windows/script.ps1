﻿rem https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_windows_powershell_ise?view=powershell-5.1
rem https://devblogs.microsoft.com/ise/about/
rem "command cmd"
$pwd.Path
pause
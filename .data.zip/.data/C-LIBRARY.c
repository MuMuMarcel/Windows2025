// <setjmp.h>	181
// <signal.h>	193
// <stdarg.h>	205
/*
* based heavily on <varargs.h>.
*
* Allows functions to accept
* argument lists such as args, kwargs.
*
* Contains argument macros for
* function headers^
*
*
*
*
*
*
*
*
*
*/
/////// A Book on C ///////
// R.E. Berry		//
// B.A.E. Meekings	//
// and M.D. Soren	//

// The Standard Library	//
// <stddef.h>	215	//
// <stdio.h>	225	//
// <stdlib.h>	333	//
// <strings.h>	387	//
//By: P.J. PLAUGER	//

//Advanced Introduction	//
//Basic Introduction	1//
//Types and Variables	17//
//Operator & Expressions65//
//Control Flow		81//
//Program and Functions	93//
//Compilation/Abstration147//
//Exceptions		171//
//Concurrent Programming189//
// The C Preprocessor	209//
// One Final Example	223//
// APPENDIX		//
// A: libc/libm 	233//
// B: lint/cc/cb/make	283//
// C: ANSI		295//
// D: ASCII		297//
//By: NARAIN GEHANI	//

//			////
// Program structure	5
// Functions		1 4
// Output and Input	2 6
// Decisions		3 8
// Loops		4 5

// Operators		5 4
/*
* TYPE CONVERSION	54
* CAST			55
* ASSIGNMENT OPERATORS	56
* ARITHMETIC OPERATORS	56
* BITWISE OPERATORS	57
* LOGICAL OPERATORS	59
* RELATIONAL OPERATORS	59
* INCREMENT & DECREMENT	60
* CONDITIONAL OPERATORS	60
* COMMA OPERATORS	61
* OPERATOR PRECEDENCE	
*
*
*
*
*
*
*/
// Arrays		6 5
// More Data Types	7 6
// Pointers revisited	8 4
// The C Preprocessor	9 9
// Appendix 1: RatC
// Appendix 2: RatC Listing
// Appendix 3: C Analysis
// Appendix 4: Screen
// Appendix 5: LInformation
// Programming structure105






